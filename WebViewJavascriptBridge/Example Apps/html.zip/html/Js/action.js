function method1() {
    alert("执行method1");
}